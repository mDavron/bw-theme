<?php

return array(
	'dependencies' => array(),
	'version' => WPCF7_VERSION,
);
